package data;

import java.awt.Button;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Ex_main {
	public static void main(String[] args) {

		Frame f = new Frame();
		f.setBounds(300, 300, 500, 500);
		f.setVisible(true);
		f.setLayout(null);

		Button btnSave = new Button("����");
		Button btnLoad = new Button("�ҷ�����");
		btnSave.setVisible(true);
		btnLoad.setVisible(true);

		btnSave.setBounds(20, 20, 50, 50);
		btnLoad.setBounds(80, 20, 50, 50);

		f.add(btnLoad);
		f.add(btnSave);

		// ��� ���� ��ư
		f.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent arg0) {
				System.exit(0);
			}

		});

		Ex_Class ec = new Ex_Class();
		Ex_save es = new Ex_save();
		

		ec.setName("daldalda");
		System.out.println(ec.getName());
		es.setName(ec.getName());
		btnSave.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				es.classSave(ec, f);

			}
		});

		btnLoad.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Ex_load el = new Ex_load(ec, f);

			}
		});

	}

}
