package main;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import data.DataEvent;

public class StartGui {
	DataEvent de;
	int i, j;

	public StartGui(DataEvent de) {
		this.de = de;
	}

	public void start() {
		
		Label loc = null;

		// ---------------------��ã�� ȭ��------------------------
		Frame f = new Frame("�� ã��");
		f.setBounds(100, 70, 800, 600);
		f.setVisible(true);
		f.setBackground(Color.GRAY);
		f.setLayout(null);

		// ��� ���� ��ư
		f.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent arg0) {
				f.dispose();
			}

		});
		
		

		// --------------��� ���̺� �߰��ϱ�(�ִ� ũ�� 16)--------------------------
		int locCnt = de.getName_list().size();
		int locy = 80;
		int[] cb = new int[locCnt];
		Checkbox[] ckb_arr = new Checkbox[locCnt];
		
		for (i = 0; i < locCnt; i++) {
			loc = new Label(de.getName_list().get(i));
			loc.setBackground(Color.WHITE);
			loc.setBounds(60, locy, 400, 20);
			f.add(loc);

			// ----------üũ�ڽ� �����---------------
			
			ckb_arr[i] = new Checkbox();
			ckb_arr[i].setBounds(510, locy, 30, 20);
			f.add(ckb_arr[i]);
			
			//-----------üũ �ڽ� �̺�Ʈ ó���� ���� �ޱ�--------------------
			locy += 30;

		}//for
		
		for(j = 0; j < locCnt; j++) {
			ckb_arr[j].addItemListener(new ItemListener() {

				@Override
				public void itemStateChanged(ItemEvent e) {
					int num = e.getStateChange() == 1 ? 1 : 0;
					//System.out.println(num);
					//System.out.println(ckb_arr.length);
					//System.out.println(i);
					cb[j] = num;
					
					
				}
			});
		}
		
		for(int i = 0; i < ckb_arr.length; i++) {
			System.out.println(cb[i]);
		}
		
		

	}

}
