package data;

import java.io.Serializable;

public class Ex_Class implements Serializable{
	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		
		this.name = name;
	}
}
