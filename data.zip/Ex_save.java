package data;

import java.awt.Button;
import java.awt.FileDialog;
import java.awt.Frame;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JOptionPane;

public class Ex_save {
	Ex_Class ex = new Ex_Class();

	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	ObjectOutputStream oos = null;
	FileOutputStream fos = null;

	// ����
	public void classSave(Ex_Class exe, Frame f) {

		ex.setName(name);
		String message = ex.getName();

		System.out.println(message);

		try {

			FileDialog fd = new FileDialog(f, "�����ϱ�", FileDialog.SAVE);
			fd.setVisible(true);

			String path = fd.getDirectory() + fd.getFile();
			System.out.println(path);

			if (!message.equals("")) {
				fos = new FileOutputStream(path);
				oos = new ObjectOutputStream(fos);

				oos.writeObject(exe);

				// FileDialog���� ��ҹ�ư�� ������ �ʰ� ���������� ������ �ܿ�
				if (fd.getFile() != null) {
					JOptionPane.showMessageDialog(f, "����Ϸ�");
				}

			} else {
				JOptionPane.showMessageDialog(f, "������ ������ ����");
			}
		} catch (Exception e2) {
			e2.printStackTrace();
			// TODO: handle exception
		} finally {
			try {
				oos.close();
				fos.close();
			} catch (Exception e3) {
				// TODO: handle exception
			}
		}
	}
}
